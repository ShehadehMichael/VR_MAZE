using UnityEngine;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit;

public class CombinedMovement : MonoBehaviour
{
    public enum MovementMethod { Thumbstick, Headset, Keyboard };
    public MovementMethod movementMethod = MovementMethod.Thumbstick;
    public float thumbstickSpeed = 1.0f; // Movement speed for thumbstick-based movement
    public float headsetSpeed = 1.0f; // Movement speed for headset-based movement
    public float keyboardSpeed = 1.0f; // Movement speed for keyboard-based movement
    public XRController leftController; // Reference to the left-hand controller
    public XRController rightController; // Reference to the right-hand controller
    public Camera cam;

    private Rigidbody rb;
    private float inputThreshold = 0.1f; // Threshold to ignore minor inputs

    private void Start()
    {
        // Cache the Rigidbody component
        rb = GetComponent<Rigidbody>();

        // Freeze rotation on all axes
        rb.constraints = RigidbodyConstraints.FreezeRotation;

        // Set collision detection mode to Continuous
        rb.collisionDetectionMode = CollisionDetectionMode.Continuous;
    }

    private void Update()
    {
        Vector3 movementDirection = Vector3.zero;

        if (movementMethod == MovementMethod.Thumbstick)
        {
            Vector2 thumbstickValue = GetThumbstickInput(leftController.inputDevice);
            if (thumbstickValue.magnitude > inputThreshold)
            {
                Vector3 right = cam.transform.right;
                right.y = 0; // Ignore vertical component
                right.Normalize();

                // Movement direction now includes vertical movement (up/down) based on the y-value of the thumbstick
                movementDirection = (Vector3.up * thumbstickValue.y + Vector3.right * -thumbstickValue.x) * thumbstickSpeed;
                // Apply movement
                Move(movementDirection);
            }
        }
        else if (movementMethod == MovementMethod.Headset)
        {
            // Headset-based movement
            Vector3 headsetForward = InputTracking.GetLocalPosition(XRNode.Head) + InputTracking.GetLocalRotation(XRNode.Head) * Vector3.forward;
            if (headsetForward.magnitude > inputThreshold)
            {
                movementDirection = new Vector3(headsetForward.x, 0f, headsetForward.z).normalized * headsetSpeed;
                // Apply movement
                Move(movementDirection);
            }
        }
        else if (movementMethod == MovementMethod.Keyboard)
        {
            // Keyboard-based movement
            float moveHorizontal = Input.GetAxis("Horizontal");
            float moveVertical = Input.GetAxis("Vertical");

            if (Mathf.Abs(moveHorizontal) > inputThreshold || Mathf.Abs(moveVertical) > inputThreshold)
            {
                Vector3 right = cam.transform.right;
                right.y = 0; // Ignore vertical component
                right.Normalize();

                // Movement direction includes vertical movement (up/down) based on the W/S keys
                movementDirection = (Vector3.up * moveVertical + Vector3.right * moveHorizontal) * keyboardSpeed;
                // Apply movement
                Move(movementDirection);
            }
        }
    }

    private void Move(Vector3 movementDirection)
    {
        // Use Rigidbody's MovePosition to move and detect collisions properly
        Vector3 newPosition = rb.position + movementDirection * Time.deltaTime;
        rb.MovePosition(newPosition);
    }

    private Vector2 GetThumbstickInput(InputDevice device)
    {
        if (device.TryGetFeatureValue(CommonUsages.primary2DAxis, out Vector2 thumbstickValue))
        {
            return thumbstickValue;
        }
        return Vector2.zero;
    }
}
