using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SolvedChecker : MonoBehaviour
{
    public Transform startPoint;
    
    public BluetoothManager Bluetoothmanager;
  
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag.Equals("Player"))
        {
            Bluetoothmanager.Sendsolved();
          Debug.Log("MAZE SOLVED: " + other.name);
            //SceneManager.LoadScene("scene");
            other.transform.position = startPoint.position;
        }
       
        // Add your custom logic here
    }
}
